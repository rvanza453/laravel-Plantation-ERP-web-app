<?php

return [
    'name' => 'AgriFlow',
];
