<?php

return [
    'name' => 'ServiceAgreementSystem',
];
