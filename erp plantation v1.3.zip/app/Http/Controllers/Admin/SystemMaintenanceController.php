<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;

class SystemMaintenanceController extends Controller
{
    private const FILE = 'modules_statuses.json';

    private const MODULE_KEY_MAP = [
        'sas' => 'ServiceAgreementSystem',
        'qc' => 'QcComplaintSystem',
        'ispo' => 'SystemISPO',
        'management' => 'management',
        'pr' => 'PrSystem',
        'systemsupport' => 'SystemSupport',
    ];

    public function index()
    {
        $status = self::getStatus();
        return view('admin.maintenance.index', compact('status'));
    }

    public function toggle(Request $request, $module)
    {
        $status = self::getStatus();
        $storageKey = self::storageKey($module);
        $status[$storageKey] = !($status[$storageKey] ?? true);
        self::persistStatus($status);
        return back()->with('success', 'Status eksekusi sistem berhasil diubah. Sistem yang mati tidak akan bisa diklik/diakses user di Module Hub.');
    }

    public function runTool(Request $request)
    {
        $validated = $request->validate([
            'admin_password' => 'required|string',
            'action' => 'required|string|in:clear_cache,reset_warehouse',
        ]);

        if (($validated['admin_password'] ?? '') !== config('app.admin_verification_password')) {
            return back()->with('error', 'Password verifikasi salah!');
        }

        if ($validated['action'] === 'clear_cache') {
            Artisan::call('optimize:clear');
            Artisan::call('cache:clear');
            Artisan::call('config:clear');
            Artisan::call('route:clear');
            Artisan::call('view:clear');

            File::deleteDirectory(storage_path('framework/cache/data'));
            File::ensureDirectoryExists(storage_path('framework/cache/data'));
            File::deleteDirectory(storage_path('framework/views'));
            File::ensureDirectoryExists(storage_path('framework/views'));

            return back()->with('success', 'Cache Laravel berhasil dibersihkan dari halaman admin.');
        }

        $warehouseStockModel = '\\Modules\\PrSystem\\Models\\WarehouseStock';
        $stockMovementModel = '\\Modules\\PrSystem\\Models\\StockMovement';
        $budgetModel = '\\Modules\\PrSystem\\Models\\Budget';

        if (! class_exists($warehouseStockModel) || ! class_exists($stockMovementModel) || ! class_exists($budgetModel)) {
            return back()->with('error', 'Fitur reset warehouse tidak tersedia karena modul PR tidak aktif.');
        }

        $warehouseStockModel::truncate();
        $stockMovementModel::truncate();
        $budgetModel::query()->update(['used_amount' => 0]);

        return back()->with('success', 'Data Warehouse, Movement, dan Budget Used Amount berhasil direset.');
    }

    public static function getStatus()
    {
        $file = base_path(self::FILE);
        $status = is_file($file) ? json_decode(file_get_contents($file), true) : null;

        if (! is_array($status)) {
            $status = [];
        }

        $status = array_merge(self::defaultStatus(), $status);

        foreach (self::MODULE_KEY_MAP as $alias => $storageKey) {
            $status[$alias] = $status[$storageKey] ?? $status[$alias] ?? true;
        }

        return $status;
    }

    private static function defaultStatus()
    {
        return [
            'ServiceAgreementSystem' => true,
            'QcComplaintSystem' => true,
            'SystemISPO' => true,
            'management' => true,
            'PrSystem' => true,
            'SystemSupport' => true,
        ];
    }

    private static function storageKey(string $module): string
    {
        return self::MODULE_KEY_MAP[$module] ?? $module;
    }

    private static function persistStatus(array $status): void
    {
        $file = base_path(self::FILE);
        $payload = [];

        foreach (self::defaultStatus() as $key => $defaultValue) {
            $payload[$key] = (bool) ($status[$key] ?? $defaultValue);
        }

        file_put_contents(
            $file,
            json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL
        );
    }
}
