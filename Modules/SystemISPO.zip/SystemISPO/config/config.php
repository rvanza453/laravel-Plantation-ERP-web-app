<?php

return [
    'name' => 'SystemISPO',
];
